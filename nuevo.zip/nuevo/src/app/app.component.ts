import { Component, Inject, OnInit, PLATFORM_ID, signal } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';

import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { LoginService } from './service/login.service';
import { CatalogosService } from './service/catalogos.service';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements OnInit {
  title = 'nuevo';
  errorMessage: string = ''; // Para manejar errores

  loginForm = signal<FormGroup>(
    new FormGroup({
      user: new FormControl('sistemas'),
      password: new FormControl('12345'),
    })
  );
  constructor(
    private serviceLogin: LoginService,
    private router: Router,
    private catalog: CatalogosService,@Inject(PLATFORM_ID) private platformId: Object
  ) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      // Aquí puedes usar window o localStorage porque estás en el navegador
      console.log('Estamos en el navegador.');
      const data = window.localStorage.getItem('myKey');
    } else {
      console.log('Estamos en el servidor.');
    }

    console.log(this.loginForm().value);
    this.serviceLogin.postLogin(this.loginForm().value).subscribe({
      next: (data) => {
        const token = data.token; // Aquí suponemos que el servidor devuelve el token en "response.token"
        this.serviceLogin.setToken(token); // Guardamos el token en localStorage
        console.log('Token almacenado:', token);
        console.log('Token almacenado:', this.serviceLogin.getToken());
        this.getOtro();
        // this.router.navigate(['/principal']); // Redirigimos a la ruta /principal
      },
      error: (err) => {
        this.errorMessage = 'Error al obtener los usuarios';
        console.error(err); // Manejo de error
      },
      complete: () => {
        console.log('Petición completa');
      },
    });
  }

  getOtro(): void {
    this.catalog.getCatCarreras().subscribe({
      next: (data) => {
        console.log('Catalogo Carreras:', data);
      },
      error: (err) => {
        this.errorMessage = 'Error al obtener los usuarios';
        console.error(err); // Manejo de error
      },
      complete: () => {
        console.log('Petición completa');
      },
    });
  }
}
