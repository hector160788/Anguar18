import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ValidacionlocalstorageService {

  constructor() { }

  isBrowser(): boolean {
console.log("en isBrowser "+(typeof window  !== 'undefined'));

    return typeof window  !== 'undefined' && typeof window.localStorage !== 'undefined';
  }
}
