import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginService } from './login.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CatalogosService {

 
  constructor(private http: HttpClient, private tokenservice: LoginService) { }

   getCatCarreras(): Observable<any> {
    const token = typeof window !== 'undefined' && window.localStorage ? Storage.arguments.localStorage.getItem('authToken'):null;
    
    console.log("***************** "+token);
    let header:HttpHeaders = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
   return  this.http.get('http://localhost:8080/titulacion/catalogos/getcatcarrera',{headers:{ 'Authorization': `Bearer ${token}`}});    
  }

   private getHeaders():HttpHeaders {
    const token = this.tokenservice.getToken();
    console.log("***************** "+token);
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }
}
