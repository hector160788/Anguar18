import { TestBed } from '@angular/core/testing';

import { ValidacionlocalstorageService } from './validacionlocalstorage.service';

describe('ValidacionlocalstorageService', () => {
  let service: ValidacionlocalstorageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ValidacionlocalstorageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
