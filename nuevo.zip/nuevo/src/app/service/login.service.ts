import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, OnInit, PLATFORM_ID } from '@angular/core';
import { Observable } from 'rxjs';
import { ValidacionlocalstorageService } from './validacionlocalstorage.service';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  constructor(
    private http: HttpClient,
    private browserService: ValidacionlocalstorageService,
    
  ) {}


  postLogin(data: any): Observable<any> {
    console.log(data);
    return this.http.post('http://localhost:8085/api/v1/login', data);
  }

  // Guardar el token en localStorage
  setToken(token: string): void {
    if (this.browserService.isBrowser()) {
      window.localStorage.setItem('authToken', token);
    }
  }

  // Obtener el token de localStorage
  getToken(): string | null {
    if (this.browserService.isBrowser()) {
      return window.localStorage.getItem('hola');
    }

    return null;
  }

  // Eliminar el token de localStorage
  removeToken(): void {
    window.localStorage.removeItem('authToken');
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }
    const payload = JSON.parse(atob(token.split('.')[1]));
    const exp = payload.exp * 1000;
    return Date.now() < exp;
  }
}
