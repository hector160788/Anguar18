export const environment = {
    production: false,
    apiUrl: 'http://localhost:8085/api/v1'
  };