export const environment = {
    production: true,
    apiUrl: 'https://api.tu-dominio.com/v1'
  };